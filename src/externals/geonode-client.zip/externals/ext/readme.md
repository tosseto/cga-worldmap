# Client-Side Externals

External client-side resources are typically included in this directory.  These
could be managed with git submodules.

The following have already been added.

    git submodule add -b 2.x git@github.com:openlayers/openlayers.git app/static/externals/openlayers
    git submodule add git@github.com:opengeo/GeoExt.git app/static/externals/geoext
    git submodule add git@github.com:opengeo/gxp.git app/static/externals/gxp


    