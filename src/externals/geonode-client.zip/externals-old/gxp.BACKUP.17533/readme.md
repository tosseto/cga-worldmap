# gxp

High level components for GeoExt based applications.

The gxp components are used by OpenGeo in their applications, such as GeoExplorer and GeoEditor.

See the [API docs](http://opengeo.github.com/gxp/) for more detail.
