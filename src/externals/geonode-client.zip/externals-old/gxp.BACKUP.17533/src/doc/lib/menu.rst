.. module:: gxp.menu
    :synopsis: A collection of map menu related classes.

:mod:`gxp.menu`
===============

The :mod:`gxp.menu` module contains classes that extend map related
functionality to ``Ext.menu`` classes.

.. toctree::
   :maxdepth: 1
   :glob:
   
   menu/*
